<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

// Pages And Posts Query

$postTypes = get_post_types( array() );
$postTypesList = array();
$excludedPostTypes = array(
	'revision',
	'nav_menu_item',
	'vc_grid_item',
);
if ( is_array( $postTypes ) && ! empty( $postTypes ) ) {
	foreach ( $postTypes as $postType ) {
		if ( ! in_array( $postType, $excludedPostTypes ) ) {
			$label = ucfirst( $postType );
			$postTypesList[] = array(
				$postType,
				$label,
			);
		}
	}
}
$postTypesList[] = array(
	'custom',
	__( 'Custom query', 'vslmd' ),
);
$postTypesList[] = array(
	'ids',
	__( 'List of IDs', 'vslmd' ),
);

// Taxonomies For Filter

$taxonomiesForFilter = array();

if ( 'vc_edit_form' === vc_post_param( 'action' ) ) {
	$vcTaxonomiesTypes = vc_taxonomies_types();
	if ( is_array( $vcTaxonomiesTypes ) && ! empty( $vcTaxonomiesTypes ) ) {
		foreach ( $vcTaxonomiesTypes as $t => $data ) {
			if ( 'post_format' !== $t && is_object( $data ) ) {
				$taxonomiesForFilter[ $data->labels->name . '(' . $t . ')' ] = $t;
			}
		}
	}
}

/*-----------------------------------------------------------------------------------*/
/*	Post
/*-----------------------------------------------------------------------------------*/

class WPBakeryShortCode_ve_post extends WPBakeryShortCode {
	protected function content( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'post_type' => '',
			'taxonomies' => '',
			'max_items' => '10',
			'style' => 'all',
			'items_per_page' => '10',
			'show_filter' => '',
			'elements_access' => '',
			'element_width' => '3',
			'gap' => '30',
			'orderby' => 'date',
			'order' => 'DESC',
			'offset' => '',
			'filter_label' => 'All',
			'filter_mode' => '',
			'filter_with_icon' => '',
			'filter_alignment' => '',
			'sort_label' => 'Sort',
			'sort_mode' => '',
			'sort_alignment' => '',
			'search_label' => 'Search',
			'search_typing' => 'yes',
			'search_typing_alignment' => '',
			'custom_search_typing_icon' => '',
			'filter_source' => '',
			'exclude_filter' => '',
			'element_layout' => 'grid',
			'show_featured_image' => 'yes',
			'featured_image_style' => '1',
			'featured_image_effect' => 'effect-none',
			'featured_image_mode' => '1',
			'element_color_scheme' => '1',
			'initial_loading_animation' => '',
			//Static
			'el_id' => '',
			'el_class' => '',
			'css' => '',
		), $atts ) );
		$output = '';
		$ve_global_color = 've-global-color'; //General Color
	  	$ve_global_border_color = 've-global-border-color'; //Border Color
	  	$ve_global_background_color = 've-global-background-color'; //Background Color


	  // Start Default Extra Class, CSS and CSS animation

	  	$css = isset( $atts['css'] ) ? $atts['css'] : '';
	  	$el_class = isset( $atts['el_class'] ) ? $atts['el_class'] : '';

	  	if ( '' !== $css_animation ) {
	  		wp_enqueue_script( 'waypoints' );
	  		$css_animation_style = ' wpb_animate_when_almost_visible wpb_' . $css_animation;
	  	}

	  	$class_to_filter = vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $el_class ) . $this->getCSSAnimation( $css_animation );
	  	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );

	  // End Default Extra Class, CSS and CSS animation

	  // Icon
	  	if ($icon_display == 'image_icon') {

	  		if($icon_alignment != '') {
	  			$icon_alignment = 'text-align:'.$icon_alignment.';';
	  		}

	  		$default_src = vc_asset_url( 'vc/no_image.png' );
	  		$img = wp_get_attachment_image_src( $custom_image_icon );
	  		$src = $img[0];
	  		$custom_src = $src ? esc_attr( $src ) : $default_src;

	  		$icon_content = '<div style="'.$icon_alignment.'"><img src="'.$custom_src.'" ></div>';

	  	} elseif ($icon_display == 'svg_icon') {

	  		if($icon_alignment != '') {
	  			$icon_alignment = 'text-align:'.$icon_alignment.';';
	  		}

	  		$default_src = vc_asset_url( 'vc/no_image.png' );
	  		$img = wp_get_attachment_image_src( $custom_svg_icon );
	  		$src = $img[0];
	  		$custom_src = $src ? esc_attr( $src ) : $default_src;

	  		$icon_content = '<div class="elvn" style="'.$icon_alignment.'"><img class="vesvg" src="'.$custom_src.'" ></div>';

	  	} else {

	  		$iconClass = isset( $icon ) ? esc_attr( $icon ) : 'fa fa-adjust';

	  		if($icon_color != '') {
	  			$custom_icon_color = 'color:'.$custom_icon_color.';';
	  			$global_icon_color = '';
	  		} else {
	  			$icon_color = '';
	  			$global_icon_color = 've-global-color';
	  		}

	  		$font_size_reference = $icon_size;

	  		if($icon_size != '') {
	  			$icon_size = 'font-size:'.$icon_size.';';
	  		}

	  		if($icon_alignment != '') {
	  			$icon_alignment = 'text-align:'.$icon_alignment.';display: block;';
	  		}

	  		if($shape != '') {

	  			if($shape == 'rounded' || $shape == 'square' || $shape == 'round') {

	  				if($color_shape != '') {
	  					$color_shape = 'background-color:'.$color_shape.';';
	  					$default_color_shape = '';
	  				} else {
	  					$color_shape = '';
	  					$default_color_shape = 've-global-background-color';
	  				}

	  			} else {

	  				if($color_shape != '') {    
	  					$color_shape = 'border-color:'.$color_shape.';';
	  					$default_color_shape = '';
	  				} else {
	  					$color_shape = '';
	  					$default_color_shape = 've-global-border-color';
	  				}

	  			}

	  			if($icon_spacing != '') {
	  				$icon_spacing = 'height:'.$icon_spacing.'; width:'.$icon_spacing.';';
	  			} else {
	  				$icon_spacing = 'height:calc('.$font_size_reference.' + 2em); width:calc('.$font_size_reference.' + 2em);';
	  			}

	  			$shape_render_start = '<div style="'.$icon_alignment.'"><div class="icon-pricing '.$shape.' '.$default_color_shape.'" style="'.$color_shape.''.$icon_spacing.'">';
	  			$shape_render_finish = '</div></div>';

	  		} else {
	  			$shape_render_start = '';
	  			$shape_render_finish = '';
	  		}

	  		$icon_content = ''.$shape_render_start.'<span style="'.$custom_icon_color.' '.$icon_size.' '.$icon_alignment.'" class="vc_icon_element-icon '.$global_icon_color.' '.$iconClass.'"></span>'.$shape_render_finish.'';
	  	}



	  // Title
	  	$title_content = '<'.$title_tag.' style="font-size:'.$title_size.';line-height:'.$title_line_height.';margin:'.$title_spacing.';text-align:'.$title_alignment.';color:'.$title_color.';">'.$title.'</'.$title_tag.'>';

	  //Price
	  	$price_content = '<p class="price" style="line-height:'.$price_line_height.';margin:'.$price_spacing.';text-align:'.$price_alignment.';color:'.$price_color.';">
	  	<span class="pricing-currency" style="font-size:'.$currency_size.';margin:'.$currency_spacing.';">'.$currency.'</span><span class="pricing-value" style="font-size:'.$price_size.';">'.$price.'</span>
	  	<span class="pricing-plan">'.$plan.'</span>
	  	</p>';

	  //Sub Heading

	  	$sub_heading_content = $content;

	  //Featured List
	  	if($features_icon == 'features-arrow') {
	  		$features_icon = 'fa-chevron-right';
	  	} else if($features_icon == 'features-check') {
	  		$features_icon = 'fa-check';
	  	} else if($features_icon == 'features-more') {
	  		$features_icon = 'fa-plus';
	  	} else {
	  		$features_icon = 'fa-star';
	  	}

	  	$featured_list = '';

	  	if($features_icon_color != '') {
	  		$features_icon_color = 'style="color:'.$features_icon_color.'"';
	  	} else {
	  		$features_icon_color = '';
	  	}

	  	if($features_line_list == 'line_list' ) {
	  		$features_line_list = 'line-list';
	  		if($features_line_list_color != '') {
	  			$features_line_list_color = 'border-bottom-color:'.$features_line_list_color.';';
	  		} else {
	  			$features_line_list_color = '';
	  		}
	  	} else {
	  		$features_line_list = '';
	  		$features_line_list_color = '';
	  	}

	  	$features_counter = 1;

	  	while( $features_counter <= 15 ){
	  		if(${'feature_' . $features_counter} != ''){
	  			$featured_list = $featured_list .'<li class="'.$features_line_list.'" style="color:'.$features_color.';padding:'.$features_spacing.';'.$features_line_list_color.'"><i '.$features_icon_color.' class="fa '.$features_icon.'"></i>'.${'feature_' . $features_counter}.'</li>';
	  		}
	  		$features_counter++;
	  	}


	  	$featured_list_content = '<div><ul class="featured-list">'.$featured_list.'</ul></div>';


	  	if($shadow_pricing_table != '') {
	  		$shadow_pricing_table = 'shadow-pricing';
	  	}

	  //Button

	  	$link = vc_build_link( $button_link );

	  	if( $button_shape == 'rounded' || $button_shape == 'square' || $button_shape == 'round' ){
	  		if($button_background_color != '') {
	  			$button_background_color = 'background-color:'.$button_background_color.';';
	  			$global_button_background_color = '';
	  		} else {
	  			$button_background_color = '';
	  			$global_button_background_color = 've-global-background-color';
	  		}
	  	} else {
	  		if($button_background_color != '') {
	  			$button_background_color = 'border-width: 2px;border-style: solid;border-color:'.$button_background_color.';';
	  			$global_button_background_color = '';
	  		} else {
	  			$button_background_color = 'border-width: 2px;border-style: solid;';
	  			$global_button_background_color = 've-global-border-color';
	  		}
	  	}

	  	$pricing_button_content = '<div class="'.$button_alignment.'"><a style="'.$button_background_color.' color:'.$button_text_color.';padding:'.$button_extra_size.';" href="'.esc_attr( $link['url'] ).'" class="'.$global_button_background_color.' '.$button_shape.' pricing-button btn '.$button_size.'" role="button">'.$button_title.'</a></div>';

	  //Layout

	  	$layout = 1;

	  	$output .= '<div class="pricing-table '.$css_class.' '.$shadow_pricing_table.'">';

	  	while( $layout <= 6 ){
	  		if(${'area_' . $layout} != '' && ${'area_' . $layout} != 'disable'){

	  			$data_content = ${'area_' . $layout} . '_content';

	  			$output .= '<div class="'.${'area_' . $layout}.'" style="margin:'.${'margin_area_' . $layout}.';padding:'.${'padding_area_' . $layout}.';background-color:'.${'background_area_' . $layout}.';">'.${$data_content}.'</div>';

	  		}
	  		$layout++;
	  	}

	  	$output .= '</div>';

	  	return $output;
	  }
	}

	return array(
		'name' => __( 'Post', 'vslmd' ),
		'base' => 've_post',
		'icon' => plugins_url('shortcodes-icon.png', __FILE__),
		'show_settings_on_create' => true,
		'category' => __( 'Visual Elements', 'vslmd' ),
		'description' => __( 'Posts or pages with filter and in grid or masonry', 'vslmd' ),
		'params' => array(

			array(
				'type' => 'dropdown',
				'heading' => __( 'Data source', 'vslmd' ),
				'param_name' => 'post_type',
				'value' => $postTypesList,
				'save_always' => true,
				'description' => __( 'Select content type.', 'vslmd' ),
				'admin_label' => true,
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Data Source', 'js_composer' ),
				'param_name' => 'taxonomies',
				'description' => __( 'Enter categories, tags or custom taxonomies. By ID.', 'js_composer' ),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Total items', 'js_composer' ),
				'param_name' => 'max_items',
				'value' => 10,
					// default value
				'param_holder_class' => 'vc_not-for-custom',
				'description' => __( 'Set max limit for items or enter -1 to display all (limited to 1000).', 'js_composer' ),
				'dependency' => array(
					'element' => 'post_type',
					'value_not_equal_to' => array(
						'ids',
						'custom',
					),
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Display Style', 'js_composer' ),
				'param_name' => 'style',
				'value' => array(
					__( 'Show all', 'js_composer' ) => 'all',
					__( 'Load more button', 'js_composer' ) => 'load-more',
					__( 'Lazy loading', 'js_composer' ) => 'lazy',
					__( 'Pagination', 'js_composer' ) => 'pagination',
				),
				'dependency' => array(
					'element' => 'post_type',
					'value_not_equal_to' => array( 'custom' ),
				),
				'edit_field_class' => 'vc_col-sm-6',
				'description' => __( 'Select display style for grid.', 'js_composer' ),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Items per page', 'js_composer' ),
				'param_name' => 'items_per_page',
				'description' => __( 'Number of items to show per page.', 'js_composer' ),
				'value' => '10',
				'dependency' => array(
					'element' => 'style',
					'value' => array(
						'lazy',
						'load-more',
						'pagination',
					),
				),
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' => 'checkbox',
				'heading' => __( 'Show filter', 'js_composer' ),
				'param_name' => 'show_filter',
				'value' => array( __( 'Yes', 'js_composer' ) => 'yes' ),
				'description' => __( 'Append filter to elements.', 'js_composer' ),
			),
			array(
				'type' => 'checkbox',
				'heading' => __( 'Elements Access', 'js_composer' ),
				'param_name' => 'elements_access',
				'value' => array( __( 'Yes', 'js_composer' ) => 'yes' ),
				'description' => __( 'Select to remove access to content page or post.', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Elements per row', 'js_composer' ),
				'param_name' => 'element_width',
				'value' => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '6',
				),
				'std' => '3',
				'edit_field_class' => 'vc_col-sm-6',
				'description' => __( 'Select number of single elements per row.', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Gap', 'js_composer' ),
				'param_name' => 'gap',
				'value' => array(
					'0px' => '0',
					'1px' => '1',
					'2px' => '2',
					'3px' => '3',
					'4px' => '4',
					'5px' => '5',
					'10px' => '10',
					'15px' => '15',
					'20px' => '20',
					'25px' => '25',
					'30px' => '30',
					'35px' => '35',
				),
				'std' => '30',
				'description' => __( 'Select gap between the elements.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-6',
			),

			// Data settings

			array(
				'type' => 'dropdown',
				'heading' => __( 'Order by', 'js_composer' ),
				'param_name' => 'orderby',
				'value' => array(
					__( 'Date', 'js_composer' ) => 'date',
					__( 'Order by post ID', 'js_composer' ) => 'ID',
					__( 'Author', 'js_composer' ) => 'author',
					__( 'Title', 'js_composer' ) => 'title',
					__( 'Last modified date', 'js_composer' ) => 'modified',
					__( 'Post/page parent ID', 'js_composer' ) => 'parent',
					__( 'Number of comments', 'js_composer' ) => 'comment_count',
					__( 'Menu order/Page Order', 'js_composer' ) => 'menu_order',
					__( 'Meta value', 'js_composer' ) => 'meta_value',
					__( 'Meta value number', 'js_composer' ) => 'meta_value_num',
					__( 'Random order', 'js_composer' ) => 'rand',
				),
				'description' => __( 'Select order type. If "Meta value" or "Meta value Number" is chosen then meta key is required.', 'js_composer' ),
				'group' => __( 'Data Settings', 'js_composer' ),
				'param_holder_class' => 'vc_grid-data-type-not-ids',
				'dependency' => array(
					'element' => 'post_type',
					'value_not_equal_to' => array(
						'ids',
						'custom',
					),
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Sort order', 'js_composer' ),
				'param_name' => 'order',
				'group' => __( 'Data Settings', 'js_composer' ),
				'value' => array(
					__( 'Descending', 'js_composer' ) => 'DESC',
					__( 'Ascending', 'js_composer' ) => 'ASC',
				),
				'param_holder_class' => 'vc_grid-data-type-not-ids',
				'description' => __( 'Select sorting order.', 'js_composer' ),
				'dependency' => array(
					'element' => 'post_type',
					'value_not_equal_to' => array(
						'ids',
						'custom',
					),
				),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Offset', 'js_composer' ),
				'param_name' => 'offset',
				'description' => __( 'Number of grid elements to displace or pass over.', 'js_composer' ),
				'group' => __( 'Data Settings', 'js_composer' ),
				'param_holder_class' => 'vc_grid-data-type-not-ids',
				'dependency' => array(
					'element' => 'post_type',
					'value_not_equal_to' => array(
						'ids',
						'custom',
					),
				),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Exclude', 'js_composer' ),
				'param_name' => 'exclude',
				'description' => __( 'Exclude posts, pages, etc. By ID.', 'js_composer' ),
				'group' => __( 'Data Settings', 'js_composer' ),
			),

			//Filter tab

			array(
				'type' => 'textfield',
				'heading' => __( 'Filter Label', 'js_composer' ),
				'param_name' => 'filter_label',
				'value' => __( 'All', 'js_composer' ),
				'description' => __( 'Enter default title for filter option display (empty: "All").', 'js_composer' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Filter Mode', 'js_composer' ),
				'param_name' => 'filter_mode',
				'value' => array(
					__( 'Filter', 'js_composer' ) => '1',
					__( 'Filter Collapsed', 'js_composer' ) => '2',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select filter mode.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-4',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Filter With Icon', 'js_composer' ),
				'param_name' => 'filter_with_icon',
				'value' => array(
					__( 'top', 'js_composer' ) => '1',
					__( 'Bottom', 'js_composer' ) => '2',
					__( 'Left', 'js_composer' ) => '3',
					__( 'Right', 'js_composer' ) => '4',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select Icon Position.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-4',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Filter Alignment', 'js_composer' ),
				'param_name' => 'filter_alignment',
				'value' => array(
					__( 'Start', 'js_composer' ) => '1',
					__( 'Center', 'js_composer' ) => '2',
					__( 'End', 'js_composer' ) => '3',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select filter alignment.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-4',
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Sort Label', 'js_composer' ),
				'param_name' => 'sort_label',
				'value' => __( 'Sort', 'js_composer' ),
				'description' => __( 'Enter default title for filter option display (empty: "Sort").', 'js_composer' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Sort Mode', 'js_composer' ),
				'param_name' => 'sort_mode',
				'value' => array(
					__( 'Sort', 'js_composer' ) => '1',
					__( 'Sort Collapsed', 'js_composer' ) => '2',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select filter mode.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Sort Alignment', 'js_composer' ),
				'param_name' => 'sort_alignment',
				'value' => array(
					__( 'Start', 'js_composer' ) => '1',
					__( 'Center', 'js_composer' ) => '2',
					__( 'End', 'js_composer' ) => '3',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select Sort alignment.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Search Label', 'js_composer' ),
				'param_name' => 'search_label',
				'value' => __( 'Search', 'js_composer' ),
				'description' => __( 'Enter default title for filter option display (empty: "Search").', 'js_composer' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
			),
			array(
				'type' => 'checkbox',
				'heading' => __( 'Show Search Typing', 'js_composer' ),
				'param_name' => 'search_typing',
				'value' => array( __( 'Yes', 'js_composer' ) => 'yes' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Enable Search Typing.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Search Typing Alignment', 'js_composer' ),
				'param_name' => 'search_typing_alignment',
				'value' => array(
					__( 'Start', 'js_composer' ) => '1',
					__( 'Center', 'js_composer' ) => '2',
					__( 'End', 'js_composer' ) => '3',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select Search Typing alignment.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Search Typing Icon', 'js_composer' ),
				'param_name' => 'search_typing_icon',
				'value' => array(
					__( 'Default Icon', 'js_composer' ) => '',
					__( 'Custom Icon', 'js_composer' ) => 'custom',
				),
				'dependency' => array(
					'element' => 'search_typing',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select icon.', 'js_composer' ),
			),
			array(
				'type' => 'iconmanager',
				'heading' => __( 'Custom Search Typing Icon', 'js_composer' ),
				'param_name' => 'custom_search_typing_icon',
				'description' => __( 'Select icon from library.', 'js_composer' ),
				'group' => __( 'Filter', 'js_composer' ),
				'dependency' => array(
					'element' => 'search_typing_icon',
					'value' => array( 'custom' ),
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Filter by', 'js_composer' ),
				'param_name' => 'filter_source',
				'value' => $taxonomiesForFilter,
				'group' => __( 'Filter', 'js_composer' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'save_always' => true,
				'description' => __( 'Select filter source.', 'js_composer' ),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Exclude From Filter List', 'js_composer' ),
				'param_name' => 'exclude_filter',
				'description' => __( 'Enter categories, tags won\'t be shown in the filters list. By ID.', 'js_composer' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
					'callback' => 'vcGridFilterExcludeCallBack',
				),
				'group' => __( 'Filter', 'js_composer' ),
			),


		// Item Design

			array(
				'type' => 'dropdown',
				'heading' => __( 'Element Layout', 'js_composer' ),
				'param_name' => 'element_layout',
				'value' => array(
					'Grid' => 'grid',
					'Masonry' => 'masonry',
				),
				'std' => 'grid',
				'group' => 'Item Design',
				'description' => __( 'Select layout style.', 'js_composer' ),
			),
			array(
				'type' => 'checkbox',
				'heading' => __( 'Show Featured Image', 'js_composer' ),
				'param_name' => 'show_featured_image',
				'value' => array( __( 'Yes', 'js_composer' ) => 'yes' ),
				'edit_field_class' => 'vc_col-sm-6',
				'group' => 'Item Design',
				'std' => 'yes',
				'description' => __( 'Show featured image on cards.', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Display Image Style', 'js_composer' ),
				'param_name' => 'featured_image_style',
				'value' => array(
					'On Top' => '1',
					'Full Card' => '2',
				),
				'dependency' => array(
					'element' => 'show_featured_image',
					'value' => array( 'yes' ),
				),
				'std' => '1',
				'edit_field_class' => 'vc_col-sm-6',
				'group' => 'Item Design',
				'description' => __( 'Select layout style.', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __('Image Effect', 'vslmd'),
				'param_name' => 'featured_image_effect',
				'value' => array(
					__('None', 'vslmd') => 'effect-none', 
					__('To Right', 'vslmd') => 'effect-right',  
					__('Zoom', 'vslmd') => 'effect-zoom', 
					__('Zoom Out', 'vslmd') => 'effect-zoom-out',  
					__('Zoom Out Right', 'vslmd') => 'effect-zoom-out-right',  
					__('Hyper Zoom', 'vslmd') => 'effect-hyper-zoom',
				),
				'dependency' => array(
					'element' => 'show_featured_image',
					'value' => array( 'yes' ),
				),
				'description' => __('Select an effect animation.', 'vslmd'),
				'edit_field_class' => 'vc_col-sm-6',
				'group' => __( 'Item Design', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Image Mode', 'js_composer' ),
				'param_name' => 'featured_image_mode',
				'value' => array(
					'Link to post' => '1',
					'Lightbox Image' => '2',
				),
				'dependency' => array(
					'element' => 'show_featured_image',
					'value' => array( 'yes' ),
				),
				'std' => '1',
				'edit_field_class' => 'vc_col-sm-6',
				'group' => 'Item Design',
				'description' => __( 'Select the image mode.', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Color Scheme', 'js_composer' ),
				'param_name' => 'element_color_scheme',
				'value' => array(
					'Light' => '1',
					'Dark' => '2',
				),
				'std' => '1',
				'description' => __( 'Select a color mode.', 'js_composer' ),
				'group' => __( 'Item Design', 'js_composer' ),
			),


			array(
				'type' => 'animation_style',
				'heading' => __( 'Initial loading animation', 'js_composer' ),
				'param_name' => 'initial_loading_animation',
				'value' => 'fadeIn',
				'settings' => array(
					'type' => array(
						'in',
						'other',
					),
				),
				'description' => __( 'Select initial loading animation for element.', 'js_composer' ),
			),

			array(
				'type' => 'el_id',
				'heading' => __( 'Element ID', 'js_composer' ),
				'param_name' => 'el_id',
				'description' => sprintf( __( 'Enter element ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'js_composer' ), 'http://www.w3schools.com/tags/att_global_id.asp' ),
			),

			array(
				'type' => 'textfield',
				'heading' => __( 'Extra class name', 'vslmd' ),
				'param_name' => 'el_class',
				'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'vslmd' ),
			),

			array(
				'type' => 'css_editor',
				'heading' => __( 'CSS box', 'vslmd' ),
				'param_name' => 'css',
				'group' => __( 'Design Options', 'vslmd' ),
			),

		),
);
