<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

// Taxonomies For Filter

$taxonomiesForFilter = array();

if ( 'vc_edit_form' === vc_post_param( 'action' ) ) {
	$vcTaxonomiesTypes = vc_taxonomies_types();
	if ( is_array( $vcTaxonomiesTypes ) && ! empty( $vcTaxonomiesTypes ) ) {
		foreach ( $vcTaxonomiesTypes as $t => $data ) {
			if ( 'post_format' !== $t && is_object( $data ) ) {
				$taxonomiesForFilter[ $data->labels->name . '(' . $t . ')' ] = $t;
			}
		}
	}
}

/*-----------------------------------------------------------------------------------*/
/*	Post
/*-----------------------------------------------------------------------------------*/

class WPBakeryShortCode_ve_review extends WPBakeryShortCode {
	protected function content( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'taxonomies' => '',
			'max_items' => '10',
			'style' => 'all',
			'items_per_page' => '10',
			'show_filter' => '',
			'elements_access' => '',
			'element_width' => '3',
			'gap' => '30',
			'orderby' => 'date',
			'order' => 'DESC',
			'offset' => '',
			'filter_label' => 'All',
			'filter_mode' => '',
			'filter_with_icon' => '',
			'filter_alignment' => '',
			'sort_label' => 'Sort',
			'sort_mode' => '',
			'sort_alignment' => '',
			'search_label' => 'Search',
			'search_typing' => 'yes',
			'search_typing_alignment' => '',
			'custom_search_typing_icon' => '',
			'filter_source' => '',
			'exclude_filter' => '',
			'element_layout' => 'grid',
			'show_featured_image' => 'yes',
			'featured_image_style' => '1',
			'featured_image_effect' => 'effect-none',
			'featured_image_mode' => '1',
			'initial_loading_animation' => '',
			//Static
			'el_id' => '',
			'el_class' => '',
			'css' => '',
		), $atts ) );
		$output = '';
		$ve_global_color = 've-global-color'; //General Color
	  	$ve_global_border_color = 've-global-border-color'; //Border Color
	  	$ve_global_background_color = 've-global-background-color'; //Background Color


	  // Start Default Extra Class, CSS and CSS animation

	  	$css = isset( $atts['css'] ) ? $atts['css'] : '';
	  	$el_class = isset( $atts['el_class'] ) ? $atts['el_class'] : '';
	  	$el_id = isset( $atts['el_id'] ) ? $atts['el_id'] : '';

	  	if ( '' !== $initial_loading_animation ) {
	  		wp_enqueue_script( 'waypoints' );
	  		$css_animation_style = ' wpb_animate_when_almost_visible wpb_' . $initial_loading_animation;
	  	}

	  	$class_to_filter = vc_shortcode_custom_css_class( $css, ' ' ) . $this->getExtraClass( $el_class ) . $this->getCSSAnimation( $initial_loading_animation );
	  	$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );

	  // End Default Extra Class, CSS and CSS animation

  	// Run query

	  	$args = array( 
	  		//'posts_per_page' => $portfolio_post_number, 
	  		'post_type' => 'review',
	  		//'portfolio-category' => $portfolio_categories,
	  		//'orderby' => $orderby,
	  		//'order' => $order
	  	);

  		$loop = new WP_Query($args);

  	// End Run query

	
	// Output Element

	  	$output .= '<div class="ve-review-post-type '.$css_class.' '.$el_id.'">';

	  		// Call Posts

	  		$output .= '<div class="card-deck">';

			  	while($loop->have_posts()) : $loop->the_post();

	  				$output .= '<div class="card">';

		  				// Post Thumbnail

		  				if(has_post_thumbnail()) {  
		  				
		  					$output .= '<img class="card-img-top" src="'. get_the_post_thumbnail_url() .'" alt="'. get_the_title() .'">';

		  				}

		  				// End Post Thumbnail

		  				$output .= '<div class="card-body">';

				  			$output .= '<a href="'. get_permalink(get_the_ID()) .'"><h6 class="card-title">'. get_the_title() .'</h6></a>';

				  			$output .= '<div class="post-location-date">
				  							<p class="card-text">
					  							<small class="text-muted">'. get_the_date() .'</small>
					  							<small class="text-muted text-right">'. get_simple_likes_button( get_the_ID() ) .'</small>
				  							</p>
				  						</div>';

				  		$output .= '</div>';

				  		$output .= '<div class="post-user-awards">
				  						<div class="card-footer">
	      									<small class="text-muted">'.get_avatar( get_the_author_meta('user_email'), $size = '32') .' '. get_the_author_meta('display_name') .'</small>';

	      									// Awards
	      									
	      									$post_type = get_post_type();
											$taxonomies = get_object_taxonomies($post_type);
											if(!empty($taxonomies)){
											    foreach($taxonomies as $taxonomy){
											    	$terms = get_the_terms( get_the_ID(), $taxonomy );
											        //$terms = get_terms($taxonomy); For Single Post Types
											        if(!empty($terms)){ 
											        	$output .= '<div class="post-awards">';
											            foreach ( $terms as $term ) {
											            	$bg = get_term_meta( $term->term_id, 'review-awards-color', true );
											                $output .= '<small style="background-color: '.$bg.';" class="text-right text-uppercase">'.get_term_meta( $term->term_id, 'review-awards-short-name', true ).'</small>';
											            }
											            $output .= '</div>';
											        }
											    }
											}

											//End Awards

    									$output .= '</div>';
									$output .= '</div>';

			  		$output .= '</div>';

				  endwhile;
				  
				  wp_reset_query();

		  	$output .= '</div>';

		  	// End Call Posts

	  	$output .= '</div>';

	  	return $output;
	  }
	}

	// End Output Element

	return array(
		'name' => __( 'Review', 'vslmd' ),
		'base' => 've_review',
		'icon' => plugins_url('shortcodes-icon.png', __FILE__),
		'show_settings_on_create' => true,
		'category' => __( 'Visual Elements', 'vslmd' ),
		'description' => __( 'Review with filter and in grid or masonry', 'vslmd' ),
		'params' => array(

			array(
				'type' => 'textfield',
				'heading' => __( 'Data Source', 'js_composer' ),
				'param_name' => 'taxonomies',
				'description' => __( 'Enter categories, tags or custom taxonomies. By ID.', 'js_composer' ),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Total items', 'js_composer' ),
				'param_name' => 'max_items',
				'value' => 10,
					// default value
				'param_holder_class' => 'vc_not-for-custom',
				'description' => __( 'Set max limit for items or enter -1 to display all (limited to 1000).', 'js_composer' ),
				'dependency' => array(
					'element' => 'post_type',
					'value_not_equal_to' => array(
						'ids',
						'custom',
					),
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Display Style', 'js_composer' ),
				'param_name' => 'style',
				'value' => array(
					__( 'Show all', 'js_composer' ) => 'all',
					__( 'Load more button', 'js_composer' ) => 'load-more',
					__( 'Lazy loading', 'js_composer' ) => 'lazy',
					__( 'Pagination', 'js_composer' ) => 'pagination',
				),
				'dependency' => array(
					'element' => 'post_type',
					'value_not_equal_to' => array( 'custom' ),
				),
				'edit_field_class' => 'vc_col-sm-6',
				'description' => __( 'Select display style for grid.', 'js_composer' ),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Items per page', 'js_composer' ),
				'param_name' => 'items_per_page',
				'description' => __( 'Number of items to show per page.', 'js_composer' ),
				'value' => '10',
				'dependency' => array(
					'element' => 'style',
					'value' => array(
						'lazy',
						'load-more',
						'pagination',
					),
				),
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' => 'checkbox',
				'heading' => __( 'Show filter', 'js_composer' ),
				'param_name' => 'show_filter',
				'value' => array( __( 'Yes', 'js_composer' ) => 'yes' ),
				'description' => __( 'Append filter to elements.', 'js_composer' ),
			),
			array(
				'type' => 'checkbox',
				'heading' => __( 'Elements Access', 'js_composer' ),
				'param_name' => 'elements_access',
				'value' => array( __( 'Yes', 'js_composer' ) => 'yes' ),
				'description' => __( 'Select to remove access to content page or post.', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Elements per row', 'js_composer' ),
				'param_name' => 'element_width',
				'value' => array(
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
					'5' => '6',
				),
				'std' => '3',
				'edit_field_class' => 'vc_col-sm-6',
				'description' => __( 'Select number of single elements per row.', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Gap', 'js_composer' ),
				'param_name' => 'gap',
				'value' => array(
					'0px' => '0',
					'1px' => '1',
					'2px' => '2',
					'3px' => '3',
					'4px' => '4',
					'5px' => '5',
					'10px' => '10',
					'15px' => '15',
					'20px' => '20',
					'25px' => '25',
					'30px' => '30',
					'35px' => '35',
				),
				'std' => '30',
				'description' => __( 'Select gap between the elements.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-6',
			),

			// Data settings

			array(
				'type' => 'dropdown',
				'heading' => __( 'Order by', 'js_composer' ),
				'param_name' => 'orderby',
				'value' => array(
					__( 'Date', 'js_composer' ) => 'date',
					__( 'Order by post ID', 'js_composer' ) => 'ID',
					__( 'Author', 'js_composer' ) => 'author',
					__( 'Title', 'js_composer' ) => 'title',
					__( 'Last modified date', 'js_composer' ) => 'modified',
					__( 'Post/page parent ID', 'js_composer' ) => 'parent',
					__( 'Number of comments', 'js_composer' ) => 'comment_count',
					__( 'Menu order/Page Order', 'js_composer' ) => 'menu_order',
					__( 'Meta value', 'js_composer' ) => 'meta_value',
					__( 'Meta value number', 'js_composer' ) => 'meta_value_num',
					__( 'Random order', 'js_composer' ) => 'rand',
				),
				'description' => __( 'Select order type. If "Meta value" or "Meta value Number" is chosen then meta key is required.', 'js_composer' ),
				'group' => __( 'Data Settings', 'js_composer' ),
				'param_holder_class' => 'vc_grid-data-type-not-ids',
				'dependency' => array(
					'element' => 'post_type',
					'value_not_equal_to' => array(
						'ids',
						'custom',
					),
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Sort order', 'js_composer' ),
				'param_name' => 'order',
				'group' => __( 'Data Settings', 'js_composer' ),
				'value' => array(
					__( 'Descending', 'js_composer' ) => 'DESC',
					__( 'Ascending', 'js_composer' ) => 'ASC',
				),
				'param_holder_class' => 'vc_grid-data-type-not-ids',
				'description' => __( 'Select sorting order.', 'js_composer' ),
				'dependency' => array(
					'element' => 'post_type',
					'value_not_equal_to' => array(
						'ids',
						'custom',
					),
				),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Offset', 'js_composer' ),
				'param_name' => 'offset',
				'description' => __( 'Number of grid elements to displace or pass over.', 'js_composer' ),
				'group' => __( 'Data Settings', 'js_composer' ),
				'param_holder_class' => 'vc_grid-data-type-not-ids',
				'dependency' => array(
					'element' => 'post_type',
					'value_not_equal_to' => array(
						'ids',
						'custom',
					),
				),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Exclude', 'js_composer' ),
				'param_name' => 'exclude',
				'description' => __( 'Exclude posts, pages, etc. By ID.', 'js_composer' ),
				'group' => __( 'Data Settings', 'js_composer' ),
			),

			//Filter tab

			array(
				'type' => 'textfield',
				'heading' => __( 'Filter Label', 'js_composer' ),
				'param_name' => 'filter_label',
				'value' => __( 'All', 'js_composer' ),
				'description' => __( 'Enter default title for filter option display (empty: "All").', 'js_composer' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Filter Mode', 'js_composer' ),
				'param_name' => 'filter_mode',
				'value' => array(
					__( 'Filter', 'js_composer' ) => '1',
					__( 'Filter Collapsed', 'js_composer' ) => '2',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select filter mode.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-4',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Filter With Icon', 'js_composer' ),
				'param_name' => 'filter_with_icon',
				'value' => array(
					__( 'top', 'js_composer' ) => '1',
					__( 'Bottom', 'js_composer' ) => '2',
					__( 'Left', 'js_composer' ) => '3',
					__( 'Right', 'js_composer' ) => '4',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select Icon Position.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-4',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Filter Alignment', 'js_composer' ),
				'param_name' => 'filter_alignment',
				'value' => array(
					__( 'Start', 'js_composer' ) => '1',
					__( 'Center', 'js_composer' ) => '2',
					__( 'End', 'js_composer' ) => '3',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select filter alignment.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-4',
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Sort Label', 'js_composer' ),
				'param_name' => 'sort_label',
				'value' => __( 'Sort', 'js_composer' ),
				'description' => __( 'Enter default title for filter option display (empty: "Sort").', 'js_composer' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Sort Mode', 'js_composer' ),
				'param_name' => 'sort_mode',
				'value' => array(
					__( 'Sort', 'js_composer' ) => '1',
					__( 'Sort Collapsed', 'js_composer' ) => '2',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select filter mode.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Sort Alignment', 'js_composer' ),
				'param_name' => 'sort_alignment',
				'value' => array(
					__( 'Start', 'js_composer' ) => '1',
					__( 'Center', 'js_composer' ) => '2',
					__( 'End', 'js_composer' ) => '3',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select Sort alignment.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Search Label', 'js_composer' ),
				'param_name' => 'search_label',
				'value' => __( 'Search', 'js_composer' ),
				'description' => __( 'Enter default title for filter option display (empty: "Search").', 'js_composer' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
			),
			array(
				'type' => 'checkbox',
				'heading' => __( 'Show Search Typing', 'js_composer' ),
				'param_name' => 'search_typing',
				'value' => array( __( 'Yes', 'js_composer' ) => 'yes' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Enable Search Typing.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Search Typing Alignment', 'js_composer' ),
				'param_name' => 'search_typing_alignment',
				'value' => array(
					__( 'Start', 'js_composer' ) => '1',
					__( 'Center', 'js_composer' ) => '2',
					__( 'End', 'js_composer' ) => '3',
				),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select Search Typing alignment.', 'js_composer' ),
				'edit_field_class' => 'vc_col-sm-6',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Search Typing Icon', 'js_composer' ),
				'param_name' => 'search_typing_icon',
				'value' => array(
					__( 'Default Icon', 'js_composer' ) => '',
					__( 'Custom Icon', 'js_composer' ) => 'custom',
				),
				'dependency' => array(
					'element' => 'search_typing',
					'value' => array( 'yes' ),
				),
				'group' => __( 'Filter', 'js_composer' ),
				'description' => __( 'Select icon.', 'js_composer' ),
			),
			array(
				'type' => 'iconmanager',
				'heading' => __( 'Custom Search Typing Icon', 'js_composer' ),
				'param_name' => 'custom_search_typing_icon',
				'description' => __( 'Select icon from library.', 'js_composer' ),
				'group' => __( 'Filter', 'js_composer' ),
				'dependency' => array(
					'element' => 'search_typing_icon',
					'value' => array( 'custom' ),
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Filter by', 'js_composer' ),
				'param_name' => 'filter_source',
				'value' => $taxonomiesForFilter,
				'group' => __( 'Filter', 'js_composer' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
				),
				'save_always' => true,
				'description' => __( 'Select filter source.', 'js_composer' ),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Exclude From Filter List', 'js_composer' ),
				'param_name' => 'exclude_filter',
				'description' => __( 'Enter categories, tags won\'t be shown in the filters list. By ID.', 'js_composer' ),
				'dependency' => array(
					'element' => 'show_filter',
					'value' => array( 'yes' ),
					'callback' => 'vcGridFilterExcludeCallBack',
				),
				'group' => __( 'Filter', 'js_composer' ),
			),


		// Item Design

			array(
				'type' => 'dropdown',
				'heading' => __( 'Element Layout', 'js_composer' ),
				'param_name' => 'element_layout',
				'value' => array(
					'Grid' => 'grid',
					'Masonry' => 'masonry',
				),
				'std' => 'grid',
				'group' => 'Item Design',
				'description' => __( 'Select layout style.', 'js_composer' ),
			),
			array(
				'type' => 'checkbox',
				'heading' => __( 'Show Featured Image', 'js_composer' ),
				'param_name' => 'show_featured_image',
				'value' => array( __( 'Yes', 'js_composer' ) => 'yes' ),
				'edit_field_class' => 'vc_col-sm-6',
				'group' => 'Item Design',
				'std' => 'yes',
				'description' => __( 'Show featured image on cards.', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Display Image Style', 'js_composer' ),
				'param_name' => 'featured_image_style',
				'value' => array(
					'On Top' => '1',
					'Full Card' => '2',
				),
				'dependency' => array(
					'element' => 'show_featured_image',
					'value' => array( 'yes' ),
				),
				'std' => '1',
				'edit_field_class' => 'vc_col-sm-6',
				'group' => 'Item Design',
				'description' => __( 'Select layout style.', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __('Image Effect', 'vslmd'),
				'param_name' => 'featured_image_effect',
				'value' => array(
					__('None', 'vslmd') => 'effect-none', 
					__('To Right', 'vslmd') => 'effect-right',  
					__('Zoom', 'vslmd') => 'effect-zoom', 
					__('Zoom Out', 'vslmd') => 'effect-zoom-out',  
					__('Zoom Out Right', 'vslmd') => 'effect-zoom-out-right',  
					__('Hyper Zoom', 'vslmd') => 'effect-hyper-zoom',
				),
				'dependency' => array(
					'element' => 'show_featured_image',
					'value' => array( 'yes' ),
				),
				'description' => __('Select an effect animation.', 'vslmd'),
				'edit_field_class' => 'vc_col-sm-6',
				'group' => __( 'Item Design', 'js_composer' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Image Mode', 'js_composer' ),
				'param_name' => 'featured_image_mode',
				'value' => array(
					'Link to post' => '1',
					'Lightbox Image' => '2',
				),
				'dependency' => array(
					'element' => 'show_featured_image',
					'value' => array( 'yes' ),
				),
				'std' => '1',
				'edit_field_class' => 'vc_col-sm-6',
				'group' => 'Item Design',
				'description' => __( 'Select the image mode.', 'js_composer' ),
			),

			array(
				'type' => 'animation_style',
				'heading' => __( 'Initial loading animation', 'js_composer' ),
				'param_name' => 'initial_loading_animation',
				'value' => 'fadeIn',
				'settings' => array(
					'type' => array(
						'in',
						'other',
					),
				),
				'description' => __( 'Select initial loading animation for element.', 'js_composer' ),
			),

			array(
				'type' => 'el_id',
				'heading' => __( 'Element ID', 'js_composer' ),
				'param_name' => 'el_id',
				'description' => sprintf( __( 'Enter element ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'js_composer' ), 'http://www.w3schools.com/tags/att_global_id.asp' ),
			),

			array(
				'type' => 'textfield',
				'heading' => __( 'Extra class name', 'vslmd' ),
				'param_name' => 'el_class',
				'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'vslmd' ),
			),

			array(
				'type' => 'css_editor',
				'heading' => __( 'CSS box', 'vslmd' ),
				'param_name' => 'css',
				'group' => __( 'Design Options', 'vslmd' ),
			),

		),
);
